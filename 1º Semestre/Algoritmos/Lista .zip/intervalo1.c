#include <stdio.h>

int main (){
    int i, x, y, li, ls, soma=0;
    scanf("%d %d", &x, &y);

    if (x>y){
        ls=x;
        li=y;
        printf("limite inferior: %d\nlimite superior: %d\n", y, x);
    }
    if (y>x){
        ls=y;
        li=x;
        printf("limite inferior: %d\nlimite superior: %d\n", x, y);
    }
    for(i=li; i<ls; i++){
        if(i%2==0){
            printf("%d ", i);
            soma+=i;
        }
    }
    printf("\n");
    printf("Soma: %d\n", soma);
    return 0;
}

