#include <stdio.h>

int main (){
	int N, NN=1, X=N;
	
	printf("Digite numeros inteiros\n");
	scanf("%d", &N);
	
	while(NN != 0){
		printf("Pra termina digite 0\n");
		scanf("%d", &NN);
		 if (N>= NN){
			 N=N;
			 NN=NN;
}
		else{
			N=NN;
			NN=X;
			}
		
		}
	printf("\nMaior numero digitado e: %d\n", N);
	
}
