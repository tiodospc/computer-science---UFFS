#include <stdio.h>

int main(){
int N=1;
float S=0, F=0;

printf("digite numeros para calcular a media\n");

while(N != 0 && N>0){
	scanf("%d", &N);
	if(N>0 && N != 0 && N%3==0){
		S+=N;
		F++;
		}
	}
	printf("media dos multiplos de 3: %.2f\n", S/F);
	
	
	return 0;
	}
