#include <stdio.h>

int main(){
	int i,s=0,m,numero;
	
	for(i=0;;i++){
	printf("Digite um numero\n");
		scanf("%d", &numero);
		if (numero<0) break;
		s+=numero; 
		m++;
	}
	printf("Soma: %d\n",s);
	printf("Media: %d\n",s/m);
	printf("Total: %d\n",m);
	
	return 0;
}
	 
	
