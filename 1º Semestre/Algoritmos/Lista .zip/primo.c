#include <stdio.h>

int main(){

    int N, i, Q=0;
    scanf("%d", &N);

    for(i=1; i<N; i++){
        if(N%i==0){
            Q++;
        }
    }
    if(Q<=1){
        printf("E primo\n");
    }else {
        printf("Não e primo\n");
    }
    return 0;
}
