#include <stdio.h>

int main (void){
int N=1, NN=1;

while (N<=3){
    while (NN<=10){

    printf("%d X %d = %d\n", N, NN, N*NN);
    NN++;
    }


printf("\n");
N++;
NN=1;
printf("\n");
}

 return 0;
}

