#include <stdio.h>

int main (){
	
	int a=0;
scanf("%d", &a)	;
		while (a)
		{
		printf("*");
		a--;
        }
	
}	
	
	
	
