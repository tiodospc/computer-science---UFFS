#include <stdio.h>

int main(void){
	int i, j, k;
	printf("Digite um numero\n");
	scanf("%d", &i);
	j=i; 
	k=i;
	while(i){
		while (j){
			printf("*");
			j--;
		}
		printf("\n");
		j=k;
		i--;
	}
	return 0;
}



