#include <stdio.h>

int main (){
	
	int a=5;	
	
		while (a)
		{
		printf("*");
		a--;
        }
	
}	
	
	
	
	
	
	
