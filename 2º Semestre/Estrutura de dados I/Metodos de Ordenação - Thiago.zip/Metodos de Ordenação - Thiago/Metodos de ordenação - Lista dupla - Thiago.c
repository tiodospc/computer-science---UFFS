#include <stdio.h>
#include <stdlib.h>

typedef struct produto{
  int codigo;
  char nome[20];
  float preco;

}tpProduto;  


typedef struct _nodo{
  tpProduto info;
  struct _nodo *next;
  struct _nodo *prev;

}tpNodo;


typedef struct _lista{			
  int nItens;
  tpNodo *first;
  tpNodo *last;

}tplista;

tplista *insere(tplista *u){

  tpNodo *N = (tpNodo *)malloc(sizeof(tpNodo));
  printf("Codigo: ");
  scanf("%d", &(N->info.codigo));
  printf("Nome: ");
  scanf("%s", (N->info.nome));
  printf("Preço: ");
  scanf("%f", &(N->info.preco));
  if(u->nItens == 0){
    u->first = N;
    u->last = N;
    u->first->next = NULL;
    u->first->prev = NULL;
    u->nItens++;
  }else{
    u->last->next = N;
    N->next = NULL;
    N->prev = u->last;
    u->last = N;
    u->nItens++;
  }
  return u; 
}	

tplista*  excluir(tplista *u, int codigo){
  tpNodo *aux, *v;
  if(u->nItens == 0){
    printf("A lista esta vazia\n");
    return NULL;
  }

  for(v = u->first  ; v != NULL  ; v = v->next) {
    if (v->info.codigo == codigo) {
      if(v == u->first){ //caso for o primeiro
	aux = u->first;
	u->first = u->first->next;
	aux->prev = NULL;
	(u->nItens)--;
      }
      else if (v == u->last) {//caso for o ultimo
	aux = u->last;
	u->last = u->last->prev;
	u->last->next = NULL;
	(u->nItens)--;
      }
      else {
	v->next->prev = v->prev;
	v->prev->next = v->next;
	(u->nItens)--;		

      }
      printf("Produto excluido\n");	

    }
  }
  free(u);
  return u;
}

void printar(tplista *lista){
  tpNodo* v = lista->first;
	for(v = lista->first; v != NULL; v = v->next){
		printf("CODIGO: %d\n", v->info.codigo);
		printf("Nome: %s\n", v->info.nome);
		printf("Preço: %.2f\n", v->info.preco);
		printf("\n\n");
  }
}
void SelectionSort(tplista *lista){
	tpNodo *andar, *trocar, *atual, *anteriordeatual, *proximodeatual, *anteriordeandar, *proximodeandar;
	if(lista->nItens==0){
			printf("Lista vazia\n");
			return ;
    }
	for(andar = lista->first; andar != NULL ; andar=andar->next){
		atual = andar;
        	printf("for principal\n");
        for(trocar = andar; trocar != NULL ; trocar=trocar->next){
        	printf("for secundario\n");
            if(trocar->info.codigo < atual->info.codigo ){
            	atual = trocar;	
            }
		}
		 if(atual != andar){
		printf("A");
		if(andar == lista->first && atual == lista->last){
			printf("j");
			lista->first = andar->next->prev = atual;
			lista->first = atual->prev->next = andar;
			atual->next = andar->next;
			andar->prev = atual->prev;
			andar->next = NULL;
			atual->prev = NULL;

		}
		else if(andar == lista->first && atual == lista->first->next){
			printf("b");
			lista->first = andar->prev = atual;
			andar->next = atual->next;
			atual->next = andar->next->prev = andar;
			atual->prev = NULL;
		}
		else if(atual == lista->last && andar==lista->last->prev){
			printf("o");
			lista->last = atual->next = andar;
			atual->prev = andar->prev;
			andar->prev = andar->prev->next = atual;
			andar->next = NULL; 
		}
		else if(andar == lista->first){
			printf("d");
			anteriordeatual = atual->prev;
			proximodeatual = atual->next;
			lista->first = andar->next->prev = atual;
			atual->next = andar->next;
			andar->prev = anteriordeatual;
			andar->next = proximodeatual;
			anteriordeatual->next = andar;
			proximodeatual->prev = andar;
			atual->prev = NULL;
		}
		else if(atual == lista->last){
			printf("g");
			anteriordeandar = andar->prev;
			proximodeandar = andar->next;
			lista->last = atual->prev->next = andar;
			andar->prev = atual->prev;
			andar->next = NULL;
			atual->prev = anteriordeandar;
			atual->next = proximodeandar;
			anteriordeandar->next = atual;
			proximodeandar->prev = atual;

		}
		else if(atual == andar->next){
			printf("h");
			atual->next->prev = andar;
			andar->prev->next = atual;
			andar->next = atual->next;
			atual->prev = andar->prev;
			atual->next = andar;
			andar->prev = atual;
			
		}
		else{
			anteriordeatual = atual->prev;
			proximodeatual  = atual->next;
			atual->next = andar->next;
			atual->prev = andar->prev;
			atual->next->prev = atual;
			atual->prev->next = atual;
			andar->next = proximodeatual;
			andar->prev = anteriordeatual;
			anteriordeatual->next = andar;
			proximodeatual->prev = andar;
		}
			andar = atual;		
	} 
			
	}
}
tplista* InsertionSort(tplista *lista){
	
	tpNodo *andar, *trocar, *atual;
	

	if(lista->nItens==0){
			printf("Lista vazia\n");
			return lista;
    }
        for(andar = lista->first->next; andar != NULL ; andar=andar->next){
        	printf("for principal\n");
            for(trocar = andar->prev; trocar != NULL ; trocar=trocar->prev){
            	printf("for secundario\n");
                atual = andar;
                
                //SE ELE É O ULTIMO E TEM QUE VIR NO COMEÇO
                if(atual->info.codigo < trocar->info.codigo && trocar==lista->first && atual==lista->last){
               	lista->last = atual->prev;
               	atual->prev->next = NULL;
               	trocar->prev = atual;
               	atual->next = trocar;
               	atual->prev = NULL;
               	lista->first = atual;
               }
                //SE ELE ESTÁ NO MEIO E TEM QUE VIR NO COMEÇO
               else if(atual->info.codigo < trocar->info.codigo && trocar==lista->first){
                    //REAPONTERAMENTO DE ONDE ELE ESTÁ
                    atual->next->prev = atual->prev;
                    atual->prev->next = atual->next;
                    //Reaponteira onde vai ir.
                    atual->next=trocar;
                    atual->prev=NULL;
                    trocar->prev=atual;
                    lista->first=atual;// Atualiza inicio
                    
                }
                //Se está no último e precisa ir pro meio
               else if(atual->info.codigo < trocar->info.codigo && atual->info.codigo <trocar->next->info.codigo && atual==lista->last){
	                atual->prev->next = NULL;
	                lista->last = atual->prev;
	                trocar->next->prev = atual;
	                atual->next = trocar->next;
	                atual->prev = trocar;
	                trocar->next = atual;
	            }    

                //Se ele está no meio e precisa ficar no meio, apenas muda de posição
                else if(atual->info.codigo > trocar->info.codigo && atual->info.codigo < trocar->next->info.codigo){
	                atual->prev->next = atual->next;
	                atual->next->prev = atual->prev;
	                trocar->next->prev = atual;
	                atual->next = trocar->next;
	                atual->prev = trocar;
	                trocar->next = atual; 
                }            
            }
       
        }

	return lista;
}

int main(){

  int codigo;	
  int op;


  tplista *lista = (tplista *)malloc(sizeof(lista));
  lista->first = NULL;
  lista->last = NULL;
  lista->nItens = 0;

  do{	


    printf("(1) Para inserir um produto na lista\n");
    printf("(2) Para excluir um elemento da lista\n");
    printf("(3) Para listar todos os campos dos elementos da lista\n");
    printf("(4) Ordenar via Insertion Sort\n");
    printf("(5) Ordenar via Selecion Sort\n");
    printf("(0) Para finalizar o programa\n");
    scanf("%d", &op);


    switch(op){

    case 1:
      lista = insere(lista);
      break; 

    case 2:
		printf("Digite o código do produto que deseja remover: ");
		scanf("%d", &codigo);
		lista = excluir(lista, codigo);
		break;

    case 3: 
		printar(lista);
		break;
	case 4:
		InsertionSort(lista);
		break;

	case 5:
		SelectionSort(lista);
		break;
    }
  }while(op != 0);



  return 0; 
}

