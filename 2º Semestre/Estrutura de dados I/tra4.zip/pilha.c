/*
 * pilha.c
 * Implementação da TAD Pilha - pilha com lista.
 */
#include <stdio.h>
#include <stdlib.h>

#include "pilha.h"

/* estrutura TAD Lista */
struct _lista {
	void* dado;
	struct _lista* prox;
};

typedef struct _lista Lista;

/* define a struct TAD pilha */
struct _pilha {
	Lista* primeiro;
};

/* cria uma pilha vazia, sendo:
 * - alocar memória para a pilha (chamar malloc)
 * - inicializar o topo (primeiro) da lista com NULL (vazia)
 * - retornar a pilha criada
 */
Pilha* pilha_cria (void)
{
	Pilha *pilha = (Pilha*) malloc(sizeof(Pilha));
	pilha->primeiro = NULL;
	return pilha;
}

/* retorna se a pilha esta vazia (true), ou false caso contrario. Verificar o valor do primeiro elemento */
bool pilha_vazia( Pilha* p )
{
	return (p->primeiro == NULL);

}

/* insere um elemento (dado) na pilha, sendo:
 - aloca memória para um novo elemento da lista
 - insere o elemento na primeira posição da lista
 */
void pilha_empilha( Pilha* p, void* dado )
{
	/*TODO Implementar inserção aqui*/
	
	Lista *Nop = (Lista*)malloc(sizeof(Lista));
	Nop->dado = dado;
	Nop->prox = p->primeiro;
	p->primeiro = Nop;	
}

/* retira o elemento do topo da pilha, sendo:
 * - verificar se a pilha está vazia (chamar função pilha_vazia)
 * - armazenar o dado removido para ser retornado
 * - retirar o primeiro elemento da lista e liberar a memória.
 * - retornar o valor removido
 */

void* pilha_desempilha( Pilha* p ) 
{
	Lista *t;
	void *v;
	
	if(pilha_vazia(p)) {
		printf("pilha vazia");
	
	}else{
		t = p->primeiro;
		v = t->dado;
		p->primeiro = t->prox;
		free(t);
		return v;	
	
	}
	
	return NULL;
}

/* libera a memória de todos os elementos e da própria pilha */
void pilha_destroi( Pilha* p )
{
	/*TODO Implementar */
	Lista *elem = p->primeiro;
		while(elem != NULL){
			Lista *rem = elem->prox;
			free(elem);
			elem = rem;
		}
		free(p);
	}


/* imprime os elementos da pilha */
void pilha_imprime( Pilha* p, void (*imprime)(void*) )
{
	if(! pilha_vazia(p)) {
	Lista *imp;
		for(imp = p->primeiro; imp != NULL; imp = imp->prox){
			imprime(imp->dado);
		}
	} else {
		printf("ERRO! Não é possível imprimir. Pilha vazia.\n");
	}	
}
