#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdio_ext.h>
#include "listam.h"
#define TAM 100


typedef struct lista{
float info;
}tp_lista;		



typedef struct nodo{
tp_lista lista;
struct nodo *prox;
}tp_nodo;



tp_nodo *inserir(tp_nodo *u){
	tp_nodo *N = (tp_nodo *)malloc(sizeof(tp_nodo));
	scanf("%f", &(N->lista.info));
	N->prox = u;
	return N;
}

tp_nodo *remover(tp_nodo *u){

	float info;
	tp_nodo *ant = NULL;
	tp_nodo *p = u;

	printf("digite o numero que deseja remover: ");
	scanf("%f", &info);
	while(p != NULL){
		if(p->lista.info == info)
			break;
		ant = p;
		p = p->prox;
	}
	if(p != NULL){
		if(ant == NULL)//PRIMEIRO ITEM A SER REMOVIDO	
			u = p->prox;	
		else //diferente do primeiro
		ant->prox = p->prox;
		free(p);	
	}			
	return u;
}

void busca(tp_nodo *u){
tp_nodo* p = u;
float info;
	printf("Digite o numero que deseja buscar: ");
	scanf("%f", &info);
	for( ; p != NULL; p= p->prox){
		if(p->lista.info == info){	
			printf("good elemento encontrado: %.2f\n", p->lista.info);
		}
	}	
}

void display(tp_nodo *u){ //for que per-corre a lista e printa na tela os produtoos 
	tp_nodo *v;
	for(v=u; v != NULL ; v = v->prox){
		printf("%.2f ", v->lista.info);
	}
} 
	


