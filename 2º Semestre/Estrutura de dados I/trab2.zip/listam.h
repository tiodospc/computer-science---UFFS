#ifndef _LISTAM_H_
#define _LISTAM_H_
 
typedef struct lista tp_lista;

typedef struct nodo tp_nodo;

tp_nodo *inserir(tp_nodo *u);

tp_nodo *remover(tp_nodo *u);

void busca(tp_nodo *u);

void display(tp_nodo *u);







#endif

