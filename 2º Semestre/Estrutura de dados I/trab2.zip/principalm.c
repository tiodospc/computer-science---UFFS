/* Nome: Thiago Henrique Ferreira Correa
   Email: thiago12812@gmail.com
   Objetivo: Lista simplismente encadeada
*/


#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include "listam.h"

int main(){		
		
int op; 

tp_nodo *u = NULL;		
		
	do{
		printf("\n");
		printf("1 - inserir numero na lista\n");
        printf("2 - retirar número\n");
        printf("3 - Buscar número\n");
        printf("4 - imprimir lista\n");
        printf("0 - sair do programa\n");
        printf("\n");
        scanf("%d", &op);
	
		switch(op){
			case 1: 
				u = inserir(u);
            break;

            case 2:
				u = remover(u);
            break;

            case 3:
				busca(u);
            break;

            case 4:
				display(u);            
			break;
			
			case 0:
			break;
			
			default:
				printf("Operação invalida\n");
		}	
	}while(op!=0);
	free(u);
	
	return 0;
}
