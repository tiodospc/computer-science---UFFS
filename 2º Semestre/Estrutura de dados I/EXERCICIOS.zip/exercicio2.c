/*Altere o programa para armazenar uma estrutura em 
cada posição do vetor.*/
typedef struct{
	char nome[50];
	char endereco[100];
	int matricula;
	}estudante; 



#include <stdio.h>
#include <stdlib.h>
int main(){
	
int  i, j;
estudante *p;

printf("Digite tamanho do vetor: ");
scanf("%d", &i);

p= (estudante *)malloc(i*sizeof(estudante));

for(j=0;j<1;j++){
	printf("posição %d: ", j+1);
	getchar();
	printf(" digite o nome do estudante: ");	
	fgets((p+j)-> nome, 50, stdin);
	printf("Digite o endereço: ");
	fgets((p+j)-> endereco, 100, stdin);
	printf("Digite a matricula: ");
	scanf("%d", &(p+j)-> matricula);
	}

system("clear");

for(j=0;j<i; j++){
	printf("estudante: %d\n", j+1);
	printf("Nome do estudante: %s\n", ((p+j)->nome));
	printf("Endereço do estudante: %s\n", ((p+j)->endereco));
	printf("Matricula do estudande: %d\n", ((p+j)->matricula));

	}


return 0;
}
