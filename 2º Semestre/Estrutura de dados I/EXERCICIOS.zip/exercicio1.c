/*Implemente um programa, para alocar memória para um 
vetor. O número de posições do vetor será indicado via 
teclado, assim como o conteúdo das posições. Após a 
atribuição de valores às posições do vetor, o programa 
deve imprimir(na tela) as posições e seus conteúdos.*/


#include <stdio.h>
#include <stdlib.h>
int main(){
	
int  i, j;
int *p;

printf("Digite tamanho do vetor: ");
scanf("%d", &i);

p= (int *)malloc(i*sizeof(int));

for ( j=0; j < i;j++){
printf("Digite os valores da posição %d: ", j+1);
scanf("%d", p+j);
}
for(j=0;j<i; j++){
	printf("Conteudo da posição %d:", j+1);
	printf("%d\n", *p);
	}


return 0;
}
