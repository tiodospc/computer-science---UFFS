/*Altere o programa do exercício 1, de forma que receba números inteiros do usuário
indefinidamente. O programa finaliza quando o usuário entrar com o número 0.
a) Aloque, inicialmente, memória para 5 inteiros;
b) Caso o usuário entrar com mais inteiros, faça a realocação, alocando espaço para mais 5
inteiros e assim sucessivamente;*/

#include <stdio.h>
#include <stdlib.h>
int main(){
	
int num, v=5, cont=0, i=0, j;
int *p;

p=(int *)malloc(5 *sizeof(int)); //ALOCA 5 ESPAÇOS 
do{
		printf("Digite numeros aleatorios: ");
		scanf("%d", (p+i));
        cont++;
	    num= *(p+i);
        i++;
        
	if(cont==5){
		int *pNew = realloc(p, 5+v * sizeof(int));
		if(pNew){
	    p= pNew; 			
		printf("Realocou memoria...\n");
	 
}else{
		printf("Memoria insuficiente\n"); 
			}
cont=0; 
	}
}while(num!=0); 
		
		for(j=0; j<i;j++){
		printf("Conteudo das posiçoes: %d\n", *(p+j));
	}



return 0; 
}
