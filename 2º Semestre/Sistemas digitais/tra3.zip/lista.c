/*
 * lista.c
 * Implementação das TADs Nodo e Sentinela - lista duplamente encadeada.
 */
#include <stdio.h>
#include <stdlib.h>

#include "lista.h"

/* define a struct TAD nodo */
struct nodo {
  Ponto* dado;        /* ponteiro para o dado da lista Ponto */
  struct nodo *prox; /* ponteiro para o proximo elemento */
  struct nodo *ant;  /* ponteiro para o elemento anterior */
};

/* define a struct TAD sentinela */
struct sentinela {
  int nItens;          /* número de elementos na lista. Atualizar ao inserir e remover da lista */
  struct nodo *cabeca; /* ponteiro para o primeiro elemento da lista */
  struct nodo *cauda;  /* ponteiro para o último elemento da lista */
};

/* cria lista vazia */
Sentinela* lista_cria(void)
{
  //Método pronto - cria a lista vazia a partir da sentinela
  Sentinela *sentinela = (Sentinela*) malloc(sizeof(Sentinela));
  sentinela->nItens = 0;
  sentinela->cabeca = NULL;
  sentinela->cauda  = NULL;
  return sentinela;
}

/* retorna se a lista esta vazia (true), ou false caso contrario */
bool lista_vazia(Sentinela* l)
{
	if(l->cabeca == NULL)
		return true;
	return false;
}

/* insere no comeco da lista, retornando a lista atualizada */
/*  insere no comeco da lista, retornando a lista atualizada */
Sentinela* lista_insere( Sentinela* l, Ponto* ponto )
{   
  /* se a lista estiver vazia */
  Nodo *N = (Nodo*)malloc(sizeof(Nodo));
  N->dado = ponto;

  if(l->nItens == 0){
    printf("nao tem itens\n");
    N->prox = NULL;
    N->ant = NULL;
    l->cabeca = N;
    l->cauda = N;
  }else{
    printf("tem items\n");
    /*se a lista tiver 1 ou mais itens*/
	
	l->cabeca->ant = N;
	N->prox = l->cabeca;
	N->ant = NULL;
	l->cabeca = N;
	
  }
  l->nItens++;
  return l;
}

/* busca um elemento na lista e retorna-o caso ele seja encontrado
   Para encontrar o ponto, utilize a função compara_ponto().	
*/
Nodo* lista_busca( Sentinela* l, Ponto* p ) {
  Nodo* i = l->cabeca;
 
  while(i != NULL){
    if(compara_ponto(i->dado, p))
      return i;		
    i = i->prox;
  }
  return NULL;
}

/* imprime todos os elementos da lista em ordem - começa da cabeça da Sentinela */
void lista_imprime_ordem( Sentinela* l ) {
 
  Nodo* d;

  for(d = l->cabeca; d != NULL ; d = d->prox){
    imprime_ponto(d->dado);
  }
 
}
	
/* imprime todos os elementos da lista em ordem inversa - começa da cauda da Sentinela */
void	 lista_imprime_ordem_inv( Sentinela* l ) {
	
  if (l == NULL) {
    printf("lista_imprime_ordem recebeu um ponteiro nulo!\n");
    return;
  }
  
  Nodo* d;
	printf("\n");
  for(d = l->cauda; d != NULL ; d = d->ant){
    imprime_ponto(d->dado);
  }
}

/* remove da lista o elemento que contem o Ponto.
   Se não encontrou, retorna 'l'. 
   Senao, o elemento removido deve ser liberrado com free.
   ATENÇÃO: não libera memória do ponto.
*/
Sentinela* lista_remove( Sentinela* l, Ponto* p ) {

  Nodo *n;
  
  for (n = l->cabeca; n != NULL && !compara_ponto(n->dado, p); n = n->prox);
  //se o ponto nao foi encontrado
  //a lista deve ser retornada sem alteracoes
  if(n == NULL) {
    return l;
  }

  if (n->prox == NULL && n->ant == NULL) {
    free(n);
    l->cabeca = NULL;
    l->cauda = NULL;
    l->nItens--;
    return l;
  }

  if (n->prox != NULL) {

    n->prox->ant = n->ant;
    
  }
  else {
    //n era o último elemento da lista
    //entao precisamos atualizar a cauda de l
    l->cauda = n->ant;
  }

  if (n->ant != NULL) {
    n->ant->prox = n->prox;
  
  }else {
    //n era  primeiro elemento da lista
    //entao precisamos atualizar a cabeca de l
    l->cabeca = n->prox;
    l->cabeca->ant = NULL;
  }
  l->nItens--;
  free(n);
  return l;
}
/* Remove todos os elementos, liberando-os. Liberar também a sentinela.
   ATENÇÃO: não libera memória do ponto. */
void lista_destroi( Sentinela* l )
{
	Nodo *n = l->cabeca;
	while(lista_vazia(l) == false){
		Nodo *r = n->prox;
			free(n);
			n = r;
			l->cabeca = n;
			printf("FUUUNCIONOUI\n");
	}
	free(l);
}
