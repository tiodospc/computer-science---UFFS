import java.util.Scanner;
public class Main{
	public static void main(String[] args){
		int n = 0;
		Empresa e = new Empresa();
		Funcionarios[] bodegueiros = new Funcionarios[n];
		Bebida[] be = new Bebida[n];


		Scanner as = new Scanner(System.in);


		System.out.println("bem vindo a bodega do joaãozin para continuar digite qualquer tecla");	
		String b = as.nextLine();


		System.out.println("1 - vender\n");
		System.out.println("2 - cadastrar funcionarios\n");
		System.out.println("3 - cadastrar bebidas\n");
		System.out.println("4 - cadastrar clientes\n");
		System.out.println("5 - exibir funcionarios\n");
		System.out.println("6 - exibir bebidas\n");
		System.out.println("7 - exibir clientes\n");
		System.out.println("0 - para sair\n");
		int a = as.nextInt();


		switch(a){

			case 1: 
			
				e.vender();
				break;
			case 2:
				bodegueiros[1] = new Funcionarios();
				bodegueiros[1].nome = "priscila";
				bodegueiros[1].cpf = "12365784";
				bodegueiros[1].salario = 1000.00;
				bodegueiros[1].funcao = "caixa";

				bodegueiros[2] = new Funcionarios();
				bodegueiros[2].nome = "thiago";
				bodegueiros[2].cpf = "12365784";
				bodegueiros[2].salario = 1000.00;
				bodegueiros[2].funcao = "gerente";	

				bodegueiros[3] = new Funcionarios();
				bodegueiros[3].nome = "carine";
				bodegueiros[3].cpf = "12365784";
				bodegueiros[3].salario = 100.00;
				bodegueiros[3].funcao = "garçonete";

				System.out.println("Quantos funcionarios deseja cadastrar");
				n = as.nextInt();
				e.Contrata();

				break;
			case 3:
				be[1] = new Bebida();
				be[1].nome = "corote";
				be[1].teor = "12 %";
				
				be[1].preco = 12.00;
				be[1].codigo = 1;
				be[1].quantidade = 10;
		
				be[2] = new Bebida();
				be[2].nome = "Catuaba";
				be[2].teor = "23 %";
				be[2].preco = 15.00;
				be[2].codigo = 2;
				be[2].quantidade = 10;
		
				be[3] = new Bebida();
				be[3].nome = "Vinho";
				be[3].teor = "10 %";
				be[3].preco = 20.00;
				be[3].codigo = 3;
				be[3].quantidade = 10; 
				System.out.println("quantas bebidas deseja cadastrar ?");
				n = as.nextInt();
				e.CadastraB();
				break;
			case 4:

				break;


			case 5:
				e.Printar();
				break;

			case 6:
				e.printarb();
				break;

			case 7: 

				break;
		}
	}
}
