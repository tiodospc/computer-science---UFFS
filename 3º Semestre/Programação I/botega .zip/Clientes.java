import java.util.Scanner;

public class Clientes{
	int n = 0;
	String nome;
	String cpf;
	Cliente cli = new Cliente[n];


	Scanner as = new Scanner(System.in);


	public void Cadastrarc(){
			cli[1] = new Cliente();
			cli[1].nome = "priscila";
			cli[1].cpf = "12365784";
		
			cli[2] = new Clientes();
			cli[2].nome = "carolina";
			cli[2].cpf = "12365784";
		

			cli[3] = new Clientes();
			cli[3].nome = "thiago";
			cli[3].cpf = "12365784";
		
			
			System.out.println("deseja cadastrar mais clientes[1 - sim /2 - não] ?");
			int a = as.nextInt();
				
				System.out.println("quantos funcionarios deseja cadastrar ?");
		
			n = as.nextInt();
			
			if(a == 1){
				for(int i=3; i<=n; i++){
					as.nextLine();
					System.out.println("Digite o nome do funcionario que deseja contratar: ");
					cli[i].nome = as.nextLine();
					System.out.println("Digite o cpf do funcionrio que deseja contratar: ");
					cli[i].cpf = as.nextLine();
					

			
	}
}
		
}
public void printarc(){

for(int i = 0; i<n; i++ ){
	System.out.println("Nome: " +cli[i].nome);
	System.out.println("cpf: " +cli[i].cpf);


}
}



}
