import java.util.Scanner;

public class Cliente{
	int n = 0;
	String nomeEm;
	String cnpj;
	Clientes cli = new Clientes();


	Scanner as = new Scanner(System.in);


	public void Contrata(){
			bodegueiros[1] = new Funcionarios();
			bodegueiros[1].nome = "priscila";
			bodegueiros[1].cpf = "12365784";
			bodegueiros[1].salario = 1000.00;
			bodegueiros[1].funcao = "caixa";
			
			bodegueiros[2] = new Funcionarios();
			bodegueiros[2].nome = "thiago";
			bodegueiros[2].cpf = "12365784";
			bodegueiros[2].salario = 1000.00;
			bodegueiros[2].funcao = "gerente";	

			bodegueiros[3] = new Funcionarios();
			bodegueiros[3].nome = "carine";
			bodegueiros[3].cpf = "12365784";
			bodegueiros[3].salario = 100.00;
			bodegueiros[3].funcao = "garçonete";

			
			System.out.println("deseja cadastras funciosarios[1 - sim /2 - não] ?");
			int a = as.nextInt();
				
				System.out.println("quantos funcionarios deseja cadastrar ?");
		
			n = as.nextInt();
			
			if(a == 1){
				for(int i=3; i<=n; i++){
					as.nextLine();
					System.out.println("Digite o nome do funcionario que deseja contratar: ");
					bodegueiros[i].nome = as.nextLine();
					System.out.println("Digite o cpf do funcionrio que deseja contratar: ");
					bodegueiros[i].cpf = as.nextLine();
					System.out.println("Digite a função do funcionario que deseja contratar: ");
					bodegueiros[i].funcao = as.nextLine();
					bodegueiros[i].salario = as.nextDouble();

			
	}
}
		
}
public void Printar(){

for(int i = 0; i<n; i++ ){
	System.out.println("Nome: " +bodegueiros[i].nome);
	System.out.println("cpf: " +bodegueiros[i].cpf);
	System.out.println("salario: " +bodegueiros[i].salario);
	System.out.println("funcao: " +bodegueiros[i].funcao);
}
}



}
