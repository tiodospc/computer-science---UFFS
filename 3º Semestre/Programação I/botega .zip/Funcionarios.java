public class Funcionarios{

String nome;
String  cpf;
double salario;
String funcao;
static int quantidadf;




public void contrata(String nome, String cpf, float salario, String função){

			this.nome = nome;
			this.cpf = cpf;
			this.salario = salario; 
			this.funcao = funcao;
			this.quantidadf++;
}	







}
