import java.util.Scanner;	

public class Bebida{		
	
 	String nome;
	String teor;
	double preco;
	static int confere;
	int codigo;
	int quantidade;


public void bebe(){
	this.teor = teor;
	this.preco = preco;
	this.codigo = codigo;
	this.quantidade = quantidade;
	this.confere++;
	
}

}
