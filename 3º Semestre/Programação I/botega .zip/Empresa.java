import java.util.Scanner;

public class Empresa{
	int n = 0;
	String nomeEm;
	String cnpj;
	Funcionarios[] bodegueiros = new Funcionarios[n];
	Bebida[] be = new Bebida[n];
	int quantidade;
	Scanner as = new Scanner(System.in);
	int codigo;

	public void Contrata(){
			

			System.out.println("deseja cadastras funciosarios[1 - sim /2 - não] ?");
			int a = as.nextInt();

			if(a == 1){
				for(int i=3; i<=n; i++){
					as.nextLine();
					System.out.println("Digite o nome do funcionario que deseja contratar: ");
					bodegueiros[i].nome = as.nextLine();
					System.out.println("Digite o cpf do funcionrio que deseja contratar: ");
					bodegueiros[i].cpf = as.nextLine();
					System.out.println("Digite a função do funcionario que deseja contratar: ");
					bodegueiros[i].funcao = as.nextLine();
					System.out.println("Digite o salario do funcionario");
					bodegueiros[i].salario = as.nextDouble();

			
	}
}
		
}
	public void Printar(){
		for(int i = 0; i<n; i++ ){
			System.out.println("Nome: " +bodegueiros[i].nome);
			System.out.println("cpf: " +bodegueiros[i].cpf);
			System.out.println("salario: " +bodegueiros[i].salario);
		System.out.println("funcao: " +bodegueiros[i].funcao);
}
}
public void CadastraB(){
	
			for(int i=3; i<n; i++){
				as.nextLine();
				System.out.println("Digite o nome: ");
				be[i].nome = as.nextLine();
				System.out.println("Digite o teor alcoólico: ");
				be[i].teor = as.nextLine();
				System.out.println("Digite o preço: ");
				be[i].preco = as.nextDouble();
				System.out.println("Digite o codigo: ");
				be[i].codigo = as.nextInt();
				System.out.println("Digite a quantidade disponivel no estoque: ");
				be[i].quantidade = as.nextInt();
			}
		}


public void	vender(){
		int a, b;
		System.out.println("Bebidas disponiveis");
		
		for(int i = 0; i<n; i++){
			System.out.println("Nome: " +be[i].nome);
			System.out.println("teor alcoólico: " +be[i].teor);
			System.out.println("preco: " +be[i].preco);
			System.out.println("codigo: " +be[i].codigo);
}

		
		System.out.println("quantas bebidas deseja vender ?");
		a = as.nextInt();

		if(a > quantidade){
			System.out.println("Estoque indisponivel");	
		}else{
			System.out.println("Digite o codigo da bebida");
			b = as.nextInt();
			if(b == codigo){
			quantidade = quantidade - a;
			System.out.println("Venda realizada com sucesso");
			System.out.println("Restam:"+this.quantidade+"dessa bebida no estoque");
		}else{
			System.out.println("Codigo da bebida não encontrado");
		}
	}
}

public void printarb(){
	for(int i = 0; i<n; i++){
	System.out.println("Nome: " +be[i].nome);
	System.out.println("teor alcoólico: " +be[i].teor);
	System.out.println("preco: " +be[i].preco);
	System.out.println("codigo: " +be[i].codigo);
}
}		





}


