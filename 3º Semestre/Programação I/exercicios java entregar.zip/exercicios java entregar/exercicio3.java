public class exercicio3{
	
	public static void main(String[] args){
		
	int n=50;
	
	while(n<=150){
		n= n+3;
		System.out.println(n);
	

		}
		}
			
		
		
		
		}
	
	
	
	}
