public class exercicio6{
	public static void main(String[] args){
	
	int x=1, y=0 ,z=1;
	
while(x<=100){
	
x= y+z;
System.out.print(x+",");
z=y;
y=x;
	
	
	}		
		
		
		}
	
	
	
	
	
	}
