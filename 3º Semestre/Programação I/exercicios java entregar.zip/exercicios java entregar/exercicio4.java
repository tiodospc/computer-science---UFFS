public class exercicio4{
	public static void main(String[] args){
		
		int fat = 1;
        for (int n = 1; n <= 10; n++) {
        fat = fat * n;
        System.out.println("int Fatorial = "+fat);

}
		
		}
	
	
	}
