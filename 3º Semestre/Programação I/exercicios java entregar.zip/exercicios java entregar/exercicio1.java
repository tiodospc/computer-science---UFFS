
public class exercicio1{
	
	public static void main(String[] args){
		
int N=118;

while(N<290){
N++;	
	System.out.println(N);	
}		
		}





}
