import java.util.Scanner;
public class exercicio7{
	
	public static void main(String[] args){
		int x;
			
		Scanner entrada= new Scanner(System.in);		
			
		System.out.println("Digite um numero: ");
		x= entrada.nextInt();

while(x!=1){		
		if(x%2==0){
		x= x/2;	
		System.out.println(x);
		}else{
		x=3*x+1;
		System.out.println(x);
}
}
}
}




