public class exercicio2{
	
	public static void main(String[] args){
		
int n=0;

while(n<500){
		n++;
		System.out.println(n);
}		
		
		
		
		
		
		}
	
	
	
	
	
	}
